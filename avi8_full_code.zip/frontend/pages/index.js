export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Avi8 ✈️</h1>
      <p>Your DGCA prep platform</p>
    </div>
  );
}
